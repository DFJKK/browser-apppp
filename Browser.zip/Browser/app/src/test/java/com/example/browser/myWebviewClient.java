package com.example.browser;

import android.webkit.WebView;

interface myWebviewClient {
    boolean

     shouldOverrideUrlLoading(WebView view, String url);
}
