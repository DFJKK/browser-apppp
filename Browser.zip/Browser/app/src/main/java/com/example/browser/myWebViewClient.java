package com.example.browser;

import android.webkit.WebChromeClient;

class myWebViewClient extends WebChromeClient {
}
